package com.peliculast2.bbfake;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BbfakeApplicationTests {

	@Test
	void contextLoads() {
	}

}
