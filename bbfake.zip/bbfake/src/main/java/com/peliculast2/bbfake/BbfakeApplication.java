package com.peliculast2.bbfake;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbfakeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BbfakeApplication.class, args);
	}

}
